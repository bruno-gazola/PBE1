package com.senaidev.cursosenai.entities;

@Entity
public class Curso {

	@Id
	private int idCurso;
	private String nomeCurso;
	private String descricao;
	private int carga;
	private int ano;
	
	//Construtores
	public Curso() {
		
	}
	
	public Curso(int idCurso, String nomeCurso, String descricao, int carga, int ano) {
		this.idCurso = idCurso;
		this.nomeCurso = nomeCurso;
		this.descricao = descricao;
		this.carga = carga;
		this.ano = ano;
	}

	
	//Getters and Setters
	public int getIdCurso() {
		return idCurso;
	}

	public void setIdCurso(int idCurso) {
		this.idCurso = idCurso;
	}

	public String getNomeCurso() {
		return nomeCurso;
	}

	public void setNomeCurso(String nomeCurso) {
		this.nomeCurso = nomeCurso;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getCarga() {
		return carga;
	}

	public void setCarga(int carga) {
		this.carga = carga;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}
	
	
	
}
