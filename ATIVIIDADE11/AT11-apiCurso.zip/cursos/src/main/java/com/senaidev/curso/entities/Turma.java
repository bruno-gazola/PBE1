package com.senaidev.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_turma")
public class Turma {
	/* Atributos */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_turma;

	@Column(name = "data_inicio")
	private String data_inicio;

	@Column(name = "data_termino")
	private String data_termino;

	@Column(name = "horario_aulas")
	private String horario_aulas;

	@Column(name = "vagas_disponiveis")
	private String vagas_disponiveis;

	/* Construtores */
	public Turma() {
		
	}

	public Turma(Long id_turma, String data_inicio, String data_termino, String horario_aulas,
		String vagas_disponiveis) {
		this.id_turma = id_turma;
		this.data_inicio = data_inicio;
		this.data_termino = data_termino;
		this.horario_aulas = horario_aulas;
		this.vagas_disponiveis = vagas_disponiveis;
	}

	/* Getters e Setters */
	public Long getId_turma() {
		return id_turma;
	}

	public void setId_turma(Long id_turma) {
		this.id_turma = id_turma;
	}

	public String getData_inicio() {
		return data_inicio;
	}

	public void setData_inicio(String data_inicio) {
		this.data_inicio = data_inicio;
	}

	public String getData_termino() {
		return data_termino;
	}

	public void setData_termino(String data_termino) {
		this.data_termino = data_termino;
	}

	public String getHorario_aulas() {
		return horario_aulas;
	}

	public void setHorario_aulas(String horario_aulas) {
		this.horario_aulas = horario_aulas;
	}

	public String getVagas_disponiveis() {
		return vagas_disponiveis;
	}

	public void setVagas_disponiveis(String vagas_disponiveis) {
		this.vagas_disponiveis = vagas_disponiveis;
	}
}
