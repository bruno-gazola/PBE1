package com.senaidev.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_aluno")
public class Aluno {
	/* Atributos */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_aluno;

	@Column(name = "nome_aluno")
	private String nome_aluno;

	@Column(name = "email_aluno")
	private String email_aluno;

	@Column(name = "telefone_aluno")
	private String telefone_aluno;

	@Column(name = "matricula")
	private String matricula;

	/* Construtores */
	public Aluno() {
		
	}
	public Aluno(Long id_aluno, String nome_aluno, String email_aluno, String telefone_aluno, String matricula) {
		this.id_aluno = id_aluno;
		this.nome_aluno = nome_aluno;
		this.email_aluno = email_aluno;
		this.telefone_aluno = telefone_aluno;
		this.matricula = matricula;
	}
	/* Getters e Setters */
	public Long getId_Aluno() {
		return id_aluno;
	}

	public void setId_Aluno(Long id_aluno) {
		this.id_aluno = id_aluno;
	}

	public String getNome_Aluno() {
		return nome_aluno;
	}

	public void setNome_Aluno(String nome_aluno) {
		this.nome_aluno = nome_aluno;
	}
	
	public String getEmail_Aluno() {
		return email_aluno;
	}

	public void setEmail_Aluno(String email_aluno) {
		this.email_aluno = email_aluno;
	}

	public String getTelefone_Aluno() {
		return telefone_aluno;
	}

	public void setTelefone_Aluno(String telefone_aluno) {
	this.telefone_aluno = telefone_aluno;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
	this.matricula = matricula;
	}
}