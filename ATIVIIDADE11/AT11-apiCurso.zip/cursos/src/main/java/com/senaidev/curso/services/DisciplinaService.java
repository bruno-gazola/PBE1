package com.senaidev.curso.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.curso.entities.Disciplina;
import com.senaidev.curso.repositories.DisciplinaRepository;

@Service
public class DisciplinaService {

	@Autowired
	private DisciplinaRepository disciplinaRepository;
	
	public Disciplina saveDisciplina(Disciplina disciplina) {
		return disciplinaRepository.save(disciplina);
	}
	public List<Disciplina> getAllDisciplinas(){
		return disciplinaRepository.findAll();
	}
	public Disciplina getDisciplinaById(Long id) {
		return disciplinaRepository.findById(id).orElse(null);
	}
	public void deleteDisciplina(Long id) {
		disciplinaRepository.deleteById(id);
	}
}
