package com.senaidev.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_curso")
public class Curso {
	/* Atributos */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_curso;

	@Column(name = "titulo")
	private String titulo;

	@Column(name = "descricao_curso")
	private String descricao_curso;

	@Column(name = "carga_horaria")
	private double carga_horaria;

	@Column(name = "nivelDificuldade")
	private String nivelDificuldade;
	
	/* Construtores */
	public Curso(){
		
	}
	public Curso(Long id_curso, String titulo, String descricao_curso, double carga_horaria, String nivelDificuldade) {
		this.id_curso = id_curso;
		this.titulo = titulo;
		this.descricao_curso = descricao_curso;
		this.carga_horaria = carga_horaria;
		this.nivelDificuldade = nivelDificuldade;
	}
	
	/* Getters e Setters */
	public Long getId_curso() {
		return id_curso;
	}
	public void setId_curso(Long id_curso) {
		this.id_curso = id_curso;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao_curso() {
		return descricao_curso;
	}
	public void setDescricao_curso(String descricao_curso) {
		this.descricao_curso = descricao_curso;
	}
	public double getCargaHoraria() {
		return carga_horaria;
	}
	public void setCargaHoraria(double carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
	public String getNivelDificuldade() {
		return nivelDificuldade;
	}
	public void setNivelDificuldade(String nivelDificuldade) {
		this.nivelDificuldade = nivelDificuldade;
	}
}
