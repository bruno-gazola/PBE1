package com.senaidev.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_disciplina")
public class Disciplina {
	/* Atributos */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_disciplina;

	@Column(name = "nome_disciplina")
	private String nome_disciplina;

	@Column(name = "descricao_disciplina")
	private String descricao_disciplina;

	@Column(name = "carga_horaria")
	private double carga_horaria;
	
	/* Construtores */
	public Disciplina() {
		
	}
	public Disciplina(Long id_disciplina, String nome_disciplina, String descricao_disciplina, double carga_horaria) {
		this.id_disciplina = id_disciplina;
		this.nome_disciplina = nome_disciplina;
		this.descricao_disciplina = descricao_disciplina;
		this.carga_horaria = carga_horaria;
	}

	/* Getters e Setters */
	public Long getId_disciplina() {
		return id_disciplina;
	}

	public void setId_disciplina(Long id_disciplina) {
		this.id_disciplina = id_disciplina;
	}

	public String getNome_disciplina() {
		return nome_disciplina;
	}

	public void setNome_disciplina(String nome_disciplina) {
		this.nome_disciplina = nome_disciplina;
	}

	public String getDescricao_disciplina() {
		return descricao_disciplina;
	}

	public void setDescricao_disciplina(String descricao_disciplina) {
		this.descricao_disciplina = descricao_disciplina;
	}

	public double getCarga_horaria() {
		return carga_horaria;
	}

	public void setCarga_horaria(double carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
}