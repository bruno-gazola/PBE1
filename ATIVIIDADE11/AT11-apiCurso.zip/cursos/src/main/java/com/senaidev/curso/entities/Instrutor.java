package com.senaidev.curso.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_instrutor")
public class Instrutor {
	/* Atributos */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_instrutor;

	@Column(name = "nome_instrutor")
	private String nome_instrutor;

	@Column(name = "email_instrutor")
	private String email_instrutor;

	@Column(name = "telefone_instrutor")
	private String telefone_instrutor;

	@Column(name = "area_especializacao")
	private String area_especializacao;

	@Column(name = "experiencia")
	private int experiencia;

	/* Construtores */
	public Instrutor() {
		
	}
	public Instrutor(Long id_instrutor, String nome_instrutor, String email_instrutor, String telefone_instrutor,
		String area_especializacao, int experiencia) {
		this.id_instrutor = id_instrutor;
		this.nome_instrutor = nome_instrutor;
		this.email_instrutor = email_instrutor;
		this.telefone_instrutor = telefone_instrutor;
		this.area_especializacao = area_especializacao;
		this.experiencia = experiencia;
	}
	
	/* Getters e Setters */
	public Long getId_instrutor() {
		return id_instrutor;
	}
	public void setId_instrutor(Long id_instrutor) {
		this.id_instrutor = id_instrutor;
	}
	public String getNome_instrutor() {
		return nome_instrutor;
	}
	public void setNome_instrutor(String nome_instrutor) {
		this.nome_instrutor = nome_instrutor;
	}
	public String getEmail_instrutor() {
		return email_instrutor;
	}
	public void setEmail_instrutor(String email_instrutor) {
		this.email_instrutor = email_instrutor;
	}
	public String getTelefone_instrutor() {
		return telefone_instrutor;
	}
	public void setTelefone_instrutor(String telefone_instrutor) {
		this.telefone_instrutor = telefone_instrutor;
	}
	public String getArea_especializacao() {
		return area_especializacao;
	}
	public void setArea_especializacao(String area_especializacao) {
		this.area_especializacao = area_especializacao;
	}
	public int getExperiencia() {
		return experiencia;
	}
	public void setExperiencia(int experiencia) {
		this.experiencia = experiencia;
	}

}