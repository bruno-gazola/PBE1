package com.senaidev.curso.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.curso.entities.Instrutor;
import com.senaidev.curso.repositories.InstrutorRepository;

@Service
public class InstrutorService {

	@Autowired
	private InstrutorRepository instrutorRepository;
	
	public Instrutor saveInstrutor(Instrutor instrutor) {
		return instrutorRepository.save(instrutor);
	}
	public List<Instrutor> getAllInstrutores(){
		return instrutorRepository.findAll();
	}
	public Instrutor getInstrutorById(Long id) {
		return instrutorRepository.findById(id).orElse(null);
	}
	public void deleteInstrutor(Long id) {
		instrutorRepository.deleteById(id);
	}
}
