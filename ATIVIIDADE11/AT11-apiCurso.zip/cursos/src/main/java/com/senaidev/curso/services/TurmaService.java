package com.senaidev.curso.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.curso.entities.Turma;
import com.senaidev.curso.repositories.TurmaRepository;

@Service
public class TurmaService {

	@Autowired
	private TurmaRepository turmaRepository;
	
	public Turma saveTurma(Turma turma) {
		return turmaRepository.save(turma);
	}
	public List<Turma> getAllTurmas(){
		return turmaRepository.findAll();
	}
	public Turma getTurmaById(Long id) {
		return turmaRepository.findById(id).orElse(null);
	}
	public void deleteTurma(Long id) {
		turmaRepository.deleteById(id);
	}
}
