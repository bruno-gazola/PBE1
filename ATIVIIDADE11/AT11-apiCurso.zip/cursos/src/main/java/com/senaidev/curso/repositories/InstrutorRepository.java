package com.senaidev.curso.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.curso.entities.Instrutor;

public interface InstrutorRepository extends JpaRepository<Instrutor, Long>{

}
