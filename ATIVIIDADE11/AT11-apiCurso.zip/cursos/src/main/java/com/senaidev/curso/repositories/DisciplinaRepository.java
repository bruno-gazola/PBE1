package com.senaidev.curso.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.curso.entities.Disciplina;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long>{

}
