package com.senaidev.curso.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.curso.entities.Turma;

public interface TurmaRepository extends JpaRepository<Turma, Long>{

}
