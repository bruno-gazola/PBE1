package com.senaidev.curso.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.curso.entities.Curso;
import com.senaidev.curso.repositories.CursoRepository;

@Service
public class CursoService {

	@Autowired
	private CursoRepository cursoRepository;
	
	public Curso saveCurso(Curso curso) {
		return cursoRepository.save(curso);
	}
	public List<Curso> getAllCursos(){
		return cursoRepository.findAll();
	}
	public Curso getCursoById(Long id) {
		return cursoRepository.findById(id).orElse(null);
	}
	public void deleteCurso(Long id) {
		cursoRepository.deleteById(id);
	}
}
