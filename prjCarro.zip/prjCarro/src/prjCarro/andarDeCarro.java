package prjCarro;

import java.util.Scanner;

public class andarDeCarro {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
    System.out.println("Informe a marca do carro: ");
    String marca = sc.next();
    
    System.out.println("Informe o modelo do carro: ");
    String modelo = sc.next();
    
    System.out.println("Informe a velocidade do carro: ");
    int velocidade = sc.nextInt();
        
        System.out.println("Para acelerar digite 1, para frear digite 2: ");
        int aceFrear = sc.nextInt();
        
        if (aceFrear == 1) {
        	System.out.println("Quanto você deseja acelerar?");
        	int acelerar = sc.nextInt();
            velocidade += acelerar;
            
        }
        else if (aceFrear == 2) {
        	System.out.println("Quanto você deseja frear?");
        	int frear = sc.nextInt();
        	velocidade -= frear;
        }
        else {
        	System.out.println("Opção inválida.");
        }
        
        System.out.println("A velocidade atual do carro "+ marca +", modelo "+ modelo +" é igual a: "+ velocidade +"Km/h");
        
        sc.close();
	}

}
