package prjCarro;

public class ContaBancaria {
	
	int numeroConta;

}
