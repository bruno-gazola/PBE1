package prjZoologico;

public class SubClasseReptil extends ClasseAnimal {
	//metodo da subclasse
		public void trocarPele() {
           System.out.println(this.atributoNome + " está trocando de pele.");
		}
		public void rastejar() {
			System.out.println(this.atributoNome + " está rastejando.");
		}
		
		@Override  
		public void metodoEmitirSom() {
			System.out.println("TSSSSS");
		}
}
