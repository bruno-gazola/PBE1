package prjZoologico;

public class Aplicacao {

	public static void main(String[] args) {
		ClasseAnimal elefante = new ClasseAnimal();
		elefante.setNome("Dumbo");
		elefante.setPeso(100);
		
		ClasseAnimal girafa = new ClasseAnimal("Github","Russa","Femea",50);
		
		SubClasseCarnivoros leao = new SubClasseCarnivoros ();
		leao.atributoNome = "leaondro";
		leao.atributoRaca = "Australeandro";
		leao.atributoSexo = "Macho";
		leao.atributoPeso = 123;
		
		leao.exibirInfo();
		leao.metodoCacar();
		
		elefante.exibirInfo();
		
		elefante.metodoComer();
		
		elefante.exibirInfo();
		
		girafa.exibirInfo();
		
		elefante.metodoEmitirSom();
		girafa.metodoEmitirSom();
		leao.metodoEmitirSom();
	}
    
}
