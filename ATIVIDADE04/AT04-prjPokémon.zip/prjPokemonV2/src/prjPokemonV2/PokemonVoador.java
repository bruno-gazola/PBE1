package prjPokemonV2;

public class PokemonVoador extends Pokemon{
       public void voar() {
    	   System.out.println(this.getnome() + " está voando.");
       }
       
       public void ataqueDeAsa() {
    	   System.out.println(this.getnome() + " está atacando com a asa.");
       }
       
       @Override
   	public void atacar() {
   		System.out.println(this.getnome() + " está atacando aéreo.");
   	}
   	
   	   @Override
   	public void evoluir() {
   		System.out.println(this.getnome() + " está evoluindo o seu poder de voar.");
   	}
   	
       
}
