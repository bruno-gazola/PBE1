package prjPokemonV2;

public class PokemonAgua extends Pokemon {
       public void surfar() {
    	   System.out.println(this.getnome() + " está surfando.");
       }
       public void canhaoAgua() {
    	   System.out.println(this.getnome() + " está lançando um canhão de água.");
       }
       @Override
   	public void atacar() {
   		System.out.println(this.getnome() + " está atacando com água.");
   	}
   	
   	@Override
   	public void evoluir() {
   		System.out.println(this.getnome() + " está evoluindo o seu poder de água.");
   	}
   	
       
}
