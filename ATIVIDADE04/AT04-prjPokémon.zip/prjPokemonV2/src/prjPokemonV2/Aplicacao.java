package prjPokemonV2;

public class Aplicacao {

	public static void main(String[] args) {
        //pokemón normal
		Pokemon pokemon1 = new Pokemon();
        pokemon1.setnome("Bulbassaur");
        pokemon1.settipo("Pokemón tipo duplo.");
        pokemon1.setnivel(16);
        pokemon1.sethp(45);
        pokemon1.setdefesa(49);
        
        Pokemon pokemon2 = new Pokemon();
        pokemon2.setnome("Venusaur");
        pokemon2.settipo("Pokemón do tipo planta e venenoso.");
        pokemon2.setnivel(40);
        pokemon2.sethp(80);
        pokemon2.setdefesa(83);
		
        //Pokemón Fogo
		PokemonFogo pokeFogo1 = new PokemonFogo();
        pokeFogo1.setnome("Charizard");
        pokeFogo1.settipo("Pokemón de fogo.");
        pokeFogo1.setnivel(80);
        pokeFogo1.sethp(100);
        pokeFogo1.setdefesa(40);
        
        PokemonFogo pokeFogo2 = new PokemonFogo();
        pokeFogo2.setnome("Charmander");
        pokeFogo2.settipo("Pokemón de fogo.");
        pokeFogo2.setnivel(20);
        pokeFogo2.sethp(39);
        pokeFogo2.setdefesa(43);
        
        //Pokemón Água
        PokemonAgua pokeAgua1 = new PokemonAgua();
        pokeAgua1.setnome("Blastoise");
        pokeAgua1.settipo("Pokemón de Água.");
        pokeAgua1.setnivel(80);
        pokeAgua1.sethp(79);
        pokeAgua1.setdefesa(120);
        
        PokemonAgua pokeAgua2 = new PokemonAgua();
        pokeAgua2.setnome("Squirtle");
        pokeAgua2.settipo("Pokemón de Água.");
        pokeAgua2.setnivel(16);
        pokeAgua2.sethp(44);
        pokeAgua2.setdefesa(65);
        
        //Pokemón Voador
        PokemonVoador pokeVoador1 = new PokemonVoador();
        pokeVoador1.setnome("Dragonite");
        pokeVoador1.settipo("Pokemón Voador.");
        pokeVoador1.setnivel(100);
        pokeVoador1.sethp(91);
        pokeVoador1.setdefesa(95);
        
        PokemonVoador pokeVoador2 = new PokemonVoador();
        pokeVoador2.setnome("Gligar");
        pokeVoador2.settipo("Pokemón Voador.");
        pokeVoador2.setnivel(75);
        pokeVoador2.sethp(70);
        pokeVoador2.setdefesa(90);
        
        //Executando
        pokemon1.exibirInfo();
        pokemon2.exibirInfo();
        pokeFogo1.exibirInfo();
        pokeFogo2.exibirInfo();
        pokeAgua1.exibirInfo();
        pokeAgua2.exibirInfo();
        pokeVoador1.exibirInfo();
        pokeVoador2.exibirInfo();
        
        pokeFogo1.atacar();
        pokeFogo1.evoluir();
		pokeFogo2.atacar();
		pokeFogo2.evoluir();
		pokeAgua1.atacar();
		pokeAgua1.evoluir();
		pokeAgua2.atacar();
		pokeAgua2.evoluir();
		pokeVoador1.atacar();
		pokeVoador1.evoluir();
		pokeVoador2.atacar();
		pokeVoador2.evoluir();
	}

}
