package prjPokemonV2;

public class Pokemon {
   //Atributos
	private String nome;
	private String tipo;
	private int nivel;
	private int hp;
	private int defesa;
	
	//Construtores
	public Pokemon() {
		
	}
	
	public Pokemon(String parametroNome, String parametroTipo, int parametroNivel, int parametroHp, int parametroDefesa) {
		this.nome = parametroNome;
		this.tipo = parametroTipo;
		this.nivel = parametroNivel;
		this.hp = parametroHp;
		this.defesa = parametroDefesa;
	}
	//Métodos
	public void atacar() {
		System.out.println(this.nome + " está atacando.");
	}
	public void evoluir() {
		System.out.println(this.nome + " está evoluindo.");
	}
	public void exibirInfo() {
		System.out.println("Nome: "+this.getnome());
		System.out.println("Tipo: "+this.gettipo());
		System.out.println("Nível: "+this.getnivel());
		System.out.println("HP: "+this.gethp());
		System.out.println("Defesa: "+this.getdefesa());
	}
	
	
	

	//Getters and Setters
	public String getnome() {
		return nome;
	}

	public void setnome(String nome) {
		this.nome = nome;
	}

	public String gettipo() {
		return tipo;
	}

	public void settipo(String tipo) {
		this.tipo = tipo;
	}

	public int getnivel() {
		return nivel;
	}

	public void setnivel(int nivel) {
		this.nivel = nivel;
	}

	public int gethp() {
		return hp;
	}

	public void sethp(int hp) {
		this.hp = hp;
	}

	public int getdefesa() {
		return defesa;
	}

	public void setdefesa(int defesa) {
		this.defesa = defesa;
	}
	
	
	

	}


