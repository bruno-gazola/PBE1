package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	public void bolaFogo() {
		System.out.println(this.getnome() + " lançando bola de fogo.");
	}
	public void explosaoFogo() {
		System.out.println(this.getnome() + " lançando explosão de fogo.");
	}
	public void lancaChamas(){
		System.out.println(this.getnome() + " lançando chamas.");
	}

	@Override
	public void atacar() {
		System.out.println(this.getnome() + " está atacando com fogo.");
	}
	
	@Override
	public void evoluir() {
		System.out.println(this.getnome() + " está evoluindo o seu poder de fogo.");
	}
	
}
