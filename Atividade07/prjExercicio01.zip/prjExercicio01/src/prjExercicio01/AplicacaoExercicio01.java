package prjExercicio01;

public class AplicacaoExercicio01 {

	public static void main(String[] args) {
		//Atribuição de Valores
		Exercicio01 carro01 = new Exercicio01();
			carro01.marca = "Chevrolet";
			carro01.modelo = "Prisma";
			carro01.ano = 2010;
			carro01.placa = "EPF3516";
			
			Exercicio01 carro02 = new Exercicio01("Hyundai","Hb20",2018,"FDX8324");
		
			//Aplicando
			carro01.exibirInfo();
			carro02.exibirInfo();
	}

}
