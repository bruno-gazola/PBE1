package prjExercicio01;

public class Exercicio01 {

	String modelo;
	String marca;
	int ano;
	String placa;

	//Construtores
	public Exercicio01(){
		
	}
	
	public Exercicio01(String modelo, String marca, int ano, String placa) {
		this.modelo = modelo;
		this.marca = marca;
		this.ano = ano;
		this.placa = placa;
	}
	
	//Métodos
	public void exibirInfo() {
		System.out.println("O modelo do carro é: "+modelo);
		System.out.println("A marca do carro é: "+marca);
		System.out.println("O ano de fabricação do carro é: "+ano);
		System.out.println("A placa do carro é: "+placa);
	}
	
}
