package prjExercicio04;

public class Caminhao extends Veiculo{

	@Override
	public void acelerar() {
		System.out.println("O caminhão está acelerando.");
	}
	
	public void frear() {
		System.out.println("O caminhão está freando.");
	}
}
