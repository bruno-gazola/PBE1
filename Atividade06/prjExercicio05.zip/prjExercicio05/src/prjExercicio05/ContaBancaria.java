package prjExercicio05;

import java.util.Scanner;

public class ContaBancaria {

	
	
	Scanner sc = new Scanner(System.in);
	
	private int numero;
	private String titular;
	private double saldo;
	
	//Construtores
	public ContaBancaria() {
		
	}
	
	public ContaBancaria(int numero, String titular, double saldo) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
	}
	
	//Métodos
	public void depositar(double valor) {
		System.out.println("Quanto você deseja depositar?");
		double deposito = sc.nextDouble();
		saldo += deposito;
	}
	
	public void sacar(double valor) {
		System.out.println("Quanto você deseja sacar?");
		valor = sc.nextInt();
		if (saldo >= valor && saldo <= 500) {
			saldo -= valor;
		}
		
		else if(saldo < valor){
			System.out.println("Saldo indisponível.");
		}
		
		else {
			System.out.println("Não é possível efetuar o saque.");
		}
	}

	//Getters and Setters
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	

}
