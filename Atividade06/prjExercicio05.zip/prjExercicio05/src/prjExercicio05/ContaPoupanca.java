package prjExercicio05;

public class ContaPoupanca extends ContaBancaria {
	double taxaJuros;
	
	public void calcularJuros() {
		setSaldo(getSaldo() + taxaJuros);
	}
	
}
