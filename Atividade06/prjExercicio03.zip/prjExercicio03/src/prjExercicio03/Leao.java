package prjExercicio03;

public class Leao extends Exercicio03{

	//Métodos de subclasses
	public void cacar() {
		System.out.println("O leão está caçando.");
	}
}
