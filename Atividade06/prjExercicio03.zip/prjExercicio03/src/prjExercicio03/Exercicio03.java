package prjExercicio03;

public class Exercicio03 {

		String nome;
		int idade;
		String raca;
		
		//Construtores
		public Exercicio03() {
			
		}
		
		public Exercicio03(String nome, int idade, String raca) {
			this.nome = nome;
			this.idade = idade;
			this.raca = raca;
	}
		
		//Métodos
		public void fazerSom() {
			System.out.println("O animal fez um som.");
		}

}
