package prjExercicio03;

public class Baleia extends Exercicio03{
	
	//Métodos de subclasses
	public void nadar() {
		System.out.println("A baleia está nadando.");
	}

}
