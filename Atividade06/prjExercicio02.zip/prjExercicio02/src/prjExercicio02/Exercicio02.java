package prjExercicio02;

public class Exercicio02 {
	String titulo;
	String autor;
	int numPaginas;
	double preco;
	
	//Construtores
	public Exercicio02(){
		
	}
	
	public Exercicio02(String titulo, String autor, int numPaginas, double preco) {
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.preco = preco;
	}
	
	//Métodos
	public void aplicarDesconto() {
		preco -= 15; 
	}
	
	public void exibirInfo() {
		System.out.println("O título do livro é: "+titulo);
		System.out.println("O autor é: "+autor);
		System.out.println("O livro tem "+numPaginas+" páginas.");
		System.out.println("Seu preço é: "+ preco);
	}

	//Getters and Setters
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
}

