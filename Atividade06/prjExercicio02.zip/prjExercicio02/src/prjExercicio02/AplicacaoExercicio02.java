package prjExercicio02;

public class AplicacaoExercicio02 {

	public static void main(String[] args) {
		//Atribuição de Valores
		Exercicio02 livro01 = new Exercicio02();
		livro01.titulo = "A culpa é das Estrelas";
		livro01.autor = "John Green";
		livro01.numPaginas = 288;
		livro01.preco = 45.00;
		
		Exercicio02 livro02 = new Exercicio02("O Pequeno Príncipe","Antoine de Saint-Exupéry",96,15.00);
		
		Exercicio02 livro03 = new Exercicio02("A Cabana","Willian P. Young",240,35.00);
		
		//Aplicando
		livro01.exibirInfo();
		livro01.aplicarDesconto();
		livro02.exibirInfo();
		livro02.aplicarDesconto();
		livro03.exibirInfo();
		livro03.aplicarDesconto();
		System.out.println("");
		System.out.println("Após os descontos seus valores são:");
		livro01.exibirInfo();
		livro02.exibirInfo();
		livro03.exibirInfo();
	}

}
