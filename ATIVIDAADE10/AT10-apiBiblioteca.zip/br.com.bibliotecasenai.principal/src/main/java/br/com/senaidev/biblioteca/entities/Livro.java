package br.com.senaidev.biblioteca.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Livro {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idLivro;
	@Column(name = "nome do livro")
	private String nomeLivro;
	@Column(name = "nome do autor")
	private String nomeAutor;
	@Column(name = "isbn")
	private String isbn;
	@Column(name = "ano")
	private int ano;
	@Column(name = "valor")
	private double valor;
	@Column(name = "estoque")
	private int estoque;
	
	
	//Construtores
	public Livro() {
		
	}
	
	public Livro(Long idLivro, String nomeLivro, String nomeAutor, String isbn, int ano, double valor, int estoque) {
		this.idLivro = idLivro;
		this.nomeLivro = nomeLivro;
		this.nomeAutor = nomeAutor;
		this.isbn = isbn;
		this.ano = ano;
		this.valor = valor;
		this.estoque = estoque;
	}

	//Getters and Setters
	public Long getIdLivro() {
		return idLivro;
	}

	public void setIdLivro(Long idLivro) {
		this.idLivro = idLivro;
	}

	public String getNomeLivro() {
		return nomeLivro;
	}

	public void setNomeLivro(String nomeLivro) {
		this.nomeLivro = nomeLivro;
	}

	public String getNomeAutor() {
		return nomeAutor;
	}

	public void setNomeAutor(String nomeAutor) {
		this.nomeAutor = nomeAutor;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public int getEstoque() {
		return estoque;
	}

	public void setEstoque(int estoque) {
		this.estoque = estoque;
	}
	
	
	
}
