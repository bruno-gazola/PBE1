package br.com.senaidev.biblioteca.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Editora {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idEditora;
	@Column(name = "nome da editora")
	private String nomeEditora;
	@Column(name = "cnpj")
	private String cnpj;
	@Column(name = "e-mail")
	private String email;
	@Column(name = "contato")
	private String contato;
	
	//Construtores
	public Editora() {
		
	}
	
	public Editora(Long idEditora, String nomeEditora, String cnpj, String email, String contato) {
		this.idEditora = idEditora;
		this.nomeEditora = nomeEditora;
		this.cnpj = cnpj;
		this.email = email;
		this.contato = contato;
	}

	
	//Getters and Setters
	public Long getIdEditora() {
		return idEditora;
	}

	public void setIdEditora(Long idEditora) {
		this.idEditora = idEditora;
	}

	public String getNomeEditora() {
		return nomeEditora;
	}

	public void setNomeEditora(String nomeEditora) {
		this.nomeEditora = nomeEditora;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContato() {
		return contato;
	}

	public void setContato(String contato) {
		this.contato = contato;
	}
	
}
