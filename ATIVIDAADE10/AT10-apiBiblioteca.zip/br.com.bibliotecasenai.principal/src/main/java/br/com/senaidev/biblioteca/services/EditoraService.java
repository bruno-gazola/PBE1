package br.com.senaidev.biblioteca.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senaidev.biblioteca.entities.Editora;
import br.com.senaidev.biblioteca.repositories.EditoraRepository;

@Service
public class EditoraService {

	@Autowired
	private EditoraRepository editoraRepository;
	
	public Editora saveEditora( Editora editora) {
		return editoraRepository.save(editora);
	}
	
	public List<Editora> getAllEditora(){
		return editoraRepository.findAll();
	}

	public Editora getEditoraById(Long id) {
		return editoraRepository.findById(id).orElse(null);
	}
	public void deleteEditora(long id) {
		editoraRepository.deleteById(id);
	}
	
}
