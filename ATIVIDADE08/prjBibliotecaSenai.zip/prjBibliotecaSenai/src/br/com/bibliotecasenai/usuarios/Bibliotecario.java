package br.com.bibliotecasenai.usuarios;

public class Bibliotecario extends Pessoa{
	String matricula;
	
	//Métodos
	public void realizarEmprestimo() {
		System.out.println(this.getNome()+" emprestou livro.");
	}
	
	public void devolverLivro() {
		System.out.println(this.getNome()+" devolveu livro");
	}
	

}
