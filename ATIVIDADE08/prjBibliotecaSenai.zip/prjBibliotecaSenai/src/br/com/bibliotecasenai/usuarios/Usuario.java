package br.com.bibliotecasenai.usuarios;

public class Usuario extends Pessoa{
	int cpf;
	int livrosEmprestados;
	
	//Construtores
	public Usuario() {
		
	}
	
	public Usuario(int cpf, int livrosEmprestados) {
		this.cpf = cpf;
		this.livrosEmprestados = livrosEmprestados;
	}
	
	//Getters and Setters
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	
	
	
	
}
