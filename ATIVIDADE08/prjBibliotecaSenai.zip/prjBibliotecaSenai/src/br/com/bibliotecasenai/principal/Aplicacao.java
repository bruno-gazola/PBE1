package br.com.bibliotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Usuario;
import br.com.bibliotecasenai.itens.Emprestimo;

public class Aplicacao {
public static void main(String[] args) {
		
	Usuario usuario01 = new Usuario();
	usuario01.setNome("Bruno");
	usuario01.setCpf(1);
	usuario01.setIdade(17);
	
	Usuario usuario02 = new Usuario();
	usuario02.setNome("Fulano");
	usuario02.setCpf(2);
	usuario02.setIdade(99);
	
	Bibliotecario bibliotecario01 = new Bibliotecario();
	bibliotecario01.setNome("Ciclano");		
	bibliotecario01.setIdade(74);		
	
	for(int i = 0;i < 10;i++) {
		//usuario01.emprestarLivro();
		
	}
		
}
}


