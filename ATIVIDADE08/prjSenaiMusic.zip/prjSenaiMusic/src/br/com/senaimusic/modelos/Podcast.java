package br.com.senaimusic.modelos;

public class Podcast extends Audio{
	//Atributos
	private String apresentador;
	private String descricao;
	
	//Getters and Setters
	public String getApresentador(){
		return this.apresentador;
	}
	
	public void setApresentador(String apresentador) {
		this.apresentador = apresentador;
	}
	
	public String getDescricao() {
		return this.descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	@Override
	public double getClassificacao() {
		if (getTotalCurtidas() > 500) {
			return 10;
		}
		else {
			return 8;
		}
		
	}
	
}
